﻿CREATE APPLICATION ROLE [ApplicationRoleExample]
	WITH PASSWORD = 'X&~8wlkormzu:raed,2tDv|`msFT7_&#$!~<#osX{,?kb|db'
