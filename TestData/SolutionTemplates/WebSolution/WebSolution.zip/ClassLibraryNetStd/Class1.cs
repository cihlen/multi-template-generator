﻿using System;

namespace ClassLibraryNetStd
{
    public class Class1
    {
    }
}
