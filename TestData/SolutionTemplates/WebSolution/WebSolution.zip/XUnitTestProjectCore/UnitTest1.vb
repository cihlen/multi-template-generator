Imports System
Imports Xunit

Namespace XUnitTestProjectCore
    Public Class UnitTest1
        <Fact>
        Sub TestSub()

        End Sub
    End Class
End Namespace

